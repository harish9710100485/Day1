document.addEventListener('DOMContentLoaded', function () {
    // Get the form element
    const form = document.querySelector('form');
    const firstName = document.getElementById('first-name');
    const lastName = document.getElementById('last-name');
    const email = document.getElementById('email');
    const phone = document.getElementById('phone');
    const gender = document.querySelectorAll('input[name="gender"]');
    const dob = document.getElementById('dob');
    const course = document.getElementById('course');
    const address = document.getElementById('address');
    const agree = document.getElementById('agree');
    
    form.addEventListener('submit', function (event) {
        let isValid = true;
        // Reset all error messages
        document.querySelectorAll('.error').forEach(function (el) {
            el.textContent = '';
        });
        
        // Check if required fields are filled
        if (firstName.value === '') {
            showError(firstName, 'First name is required');
            isValid = false;
        }
        
        if (lastName.value === '') {
            showError(lastName, 'Last name is required');
            isValid = false;
        }
        
        if (email.value === '' || !validateEmail(email.value)) {
            showError(email, 'Valid email is required');
            isValid = false;
        }
        
        if (phone.value === '' || !/^\d{10}$/.test(phone.value)) {
            showError(phone, 'Valid phone number is required');
            isValid = false;
        }
        
        if (![...gender].some(g => g.checked)) {
            showError(document.querySelector('.form-group'), 'Please select your gender');
            isValid = false;
        }
        
        if (dob.value === '') {
            showError(dob, 'Date of birth is required');
            isValid = false;
        }
        
        if (course.value === '') {
            showError(course, 'Please select a course');
            isValid = false;
        }
        
        if (address.value === '') {
            showError(address, 'Address is required');
            isValid = false;
        }
        
        if (!agree.checked) {
            showError(agree, 'You must agree to the terms and conditions');
            isValid = false;
        }
        
        // If any validation failed, prevent form submission
        if (!isValid) {
            event.preventDefault();
        }
    });
    
    function showError(element, message) {
        let error = document.createElement('span');
        error.classList.add('error');
        error.textContent = message;
        element.parentNode.appendChild(error);
    }
    
    function validateEmail(email) {
        const regex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        return regex.test(email);
    }
});
